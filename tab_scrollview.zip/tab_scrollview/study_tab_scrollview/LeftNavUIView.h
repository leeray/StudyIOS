//
//  LeftNavUIView.h
//  study_tab_scrollview
//
//  Created by 李 瑞 on 13-3-25.
//  Copyright (c) 2013年 李 瑞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftNavUIView : UIView

- (void)initWithFrame:(CGRect)frame delegate:(id)delegate;

@end
