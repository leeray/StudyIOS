//
//  RightNavUIView.m
//  study_tab_scrollview
//
//  Created by 李 瑞 on 13-3-26.
//  Copyright (c) 2013年 李 瑞. All rights reserved.
//

#import "RightNavUIView.h"

@implementation RightNavUIView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)initWithFrame:(CGRect)frame delegate:(id)delegate{
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
